sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageBox"
], function (Controller, JSONModel, MessageBox) {
	"use strict";
	var that;
	var homeView;
	var bcTable;
	var datePicker;
	/*var IconTabBarController = Controller.extend("sap.m.sample.IconTabBar.IconTabBar", {*/
	return Controller.extend("UI.UI.controller.Home", {
		onInit: function () {
			that = this;
			homeView = this.getView();
			//this.loadComboBoxData();
			bcTable = this.getView().byId("dropDownforTable").getSelectedKey();
			this.byId("DP3").setDateValue(new Date());
			this.byId("DP2").setDateValue(new Date());
			this.loadFxratesTableModel(null, null);
			this.loadCompareRatesModel();
		},
		onPress: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ManualEntry");
		},
		onPressManual: function (oEvent) {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("ManualEntry");
		},
		onSelectTab: function (oEvent) {
			/*var sKey = oEvent.getParameter("key");
			if (sKey === "home") {
				this.getView().byId("manualUpdate").setVisible(false);
				this.getView().byId("ratesTable").setVisible(false);

			}
			if (sKey === "ratestable") {
				this.getView().byId("manualUpdate").setVisible(false);
				this.getView().byId("homePanel").setVisible(false);
			}

			if (sKey === "lookup") {
				this.getView().byId("manualUpdate").setVisible(false);
				this.getView().byId("homePanel").setVisible(false);

			}
			if (sKey === "calculator") {
				this.getView().byId("manualUpdate").setVisible(false);
				this.getView().byId("homePanel").setVisible(false);

			}
			if (sKey === "compare") {
				this.getView().byId("manualUpdate").setVisible(false);
				this.getView().byId("homePanel").setVisible(false);

			}
			if (sKey === "manual") {
				this.getView().byId("ratesTable").setVisible(false);
				this.getView().byId("homePanel").setVisible(false);

			}
			*/

		},
		onInsert: function () {
			var oEntity = {};
			var url = "/fxrates/addEntry";
			var basecurrency = this.getView().byId("manualU1").getSelectedKey();
			var tocurrency = this.getView().byId("manualU2").getSelectedKey();
			var res1 = basecurrency.substring(0, 3);
			var res2 = tocurrency.substring(0, 3);
			/*	oEntity.baseCurrency = homeView.byId("baseCurrency").getValue();
				oEntity.toCurrency = homeView.byId("toCurrency").getValue();*/

			oEntity.baseCurrency = res1;
			oEntity.toCurrency = res2;
			oEntity.rate = homeView.byId("rateInput").getValue();
			//	console.log(jsondata);
			$.ajax({
				url: url,
				contentType: 'application/json; charset=UTF-8',
				type: 'PUT',
				data: JSON.stringify(oEntity),
				async: false,
				cache: false,
				success: function (res) {
					MessageBox.confirm(
						"Record Inserted Sucessfully", {});
				},
				error: function (res) {
					MessageBox.confirm(
						"Failed to insert record", {});
				}
			});

		},
		formatDate: function(date) {
			var day = ('0'+date.getDate()).slice(-2);
			var monthIndex = ('0'+(date.getMonth()+1)).slice(-2);
			var year = date.getFullYear();

			return day + '-' + monthIndex + '-' + year;
		},
	
		/*handleChange: function (oEvent) {
			var oText = this.byId("textResult");
			var oDP = oEvent.getSource();
			var sValue = oEvent.getParameter("value");
			var bValid = oEvent.getParameter("valid");
			this._iEvent++;
			oText.setText("Change - Event " + this._iEvent + ": DatePicker " + oDP.getId() + ":" + sValue);

			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},*/
		handleChange: function (oEvent) {
			var oValidatedComboBox = oEvent.getSource(),
				sSelectedKey = oValidatedComboBox.getSelectedKey();
			bcTable = sSelectedKey.substring(0, 3);
			datePicker = that.formatDate(that.byId("DP3").getDateValue());
			that.loadFxratesTableModel(bcTable, datePicker);
			/*var url = "/fxrates/getRates/" + bcTable;
			var fxratesModel = new sap.ui.model.json.JSONModel();
			fxratesModel.loadData(url, null, false);
			homeView.byId("RatesTable").setModel(fxratesModel);
			homeView.byId("RatesTable").bindRows("/");*/
			if (!sSelectedKey) {
				oValidatedComboBox.setValueState("Error");
				oValidatedComboBox.setValueStateText("Please enter a valid Value!");
			} else {
				oValidatedComboBox.setValueState("None");
			}
		},
		handleDate: function (oEvent) {
			var oDP = oEvent.getSource();
			var sValue = oEvent.getParameter("value");
			sValue = sValue.replace("/", "-");
			var find = '/';
			var re = new RegExp(find, 'g');
			sValue = sValue.replace(re, '-');
			var bValid = oEvent.getParameter("valid");
			this._iEvent++;
			if (!bcTable) {
				bcTable = "USD";
			}
			if (bValid) {
				oDP.setValueState(sap.ui.core.ValueState.None);
				that.loadFxratesTableModel(bcTable, sValue);
			} else {
				oDP.setValueState(sap.ui.core.ValueState.Error);
			}
		},
		replaceAll: function (str, find, replace) {
			return str.replace(new RegExp(find, 'g'), replace);
		},

		loadCompareRatesModel: function () {
			var url = "/fxrates/CompareRates";
			var compareRatesesModel = new sap.ui.model.json.JSONModel();
			compareRatesesModel.loadData(url, null, false);
			homeView.byId("compareRatesTable").setModel(compareRatesesModel);
			homeView.byId("compareRatesTable").bindRows("/");
		},

		loadFxratesTableModel: function (bcTable, datePicker) {
			if (datePicker && bcTable) {
				var url = "/fxrates/getRates/" + bcTable + "/" + datePicker;
			} else if (bcTable) {
				var url = "/fxrates/getRates/" + bcTable + "/nodate";
			} else if (datePicker) {
				var url = "/fxrates/getRates/USD/" + datePicker;
			} else {
				var url = "/fxrates/getRates/USD/nodate";
			}
			//	homeView.byId("DP3").setDateValue(new Date());
			var fxratesModel = new sap.ui.model.json.JSONModel();
			/*fxratesModel.setData({
				dateValue: new Date()
			});*/
			fxratesModel.loadData(url, null, false);

			homeView.byId("RatesTable").setModel(fxratesModel);
			//	homeView.byId("idComboBox").setModel(fxratesModel);
			homeView.byId("RatesTable").bindRows("/");
			//	homeView.byId("idComboBox").bindRows("/records");
		}
		

	});
	//	return IconTabBarController;

});