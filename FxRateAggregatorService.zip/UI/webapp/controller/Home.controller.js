sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function (Controller, MessageBox) {
	"use strict";
	var homeView;
	var that;

	return Controller.extend("UI.UI.controller.Home", {
		onInit: function () {
			that = this;
            homeView = this.getView();
		},
		onInsert: function () {
			var url = "/fxrates/addapi";
			var oEntity = {};
			/*	var basecurrency = this.getView().byId("apiName").getValue();
				var tocurrency = this.getView().byId("apiUrl").getValue();*/
			oEntity.apiName = homeView.byId("apiName").getValue();
			oEntity.apiUrl = homeView.byId("apiUrl").getValue();
			console.log(oEntity);
			$.ajax({
				url: url,
				contentType: 'application/json; charset=UTF-8',
				type: 'PUT',
				data: JSON.stringify(oEntity),
				async: false,
				cache: false,
				success: function (res) {
					MessageBox.confirm(
						"Record Inserted Sucessfully", {});
				},
				error: function (res) {
					MessageBox.confirm(
						"Failed to insert record", {});
				}
			});
			that.onClear();
		},
		onClear: function () {
			homeView.byId("apiName").setValue(null);
			homeView.byId("apiUrl").setValue(null);
		}
	});
});